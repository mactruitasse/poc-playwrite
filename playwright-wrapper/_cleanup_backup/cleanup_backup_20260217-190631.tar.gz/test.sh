#!/usr/bin/env bash
set -euo pipefail

### =========================
### Config (modifiable)
### =========================
REPO_DIR="${REPO_DIR:-.}"

# Fichiers à embarquer
FILES=(
  "app/main.py"
  "app/settings.py"
  "Dockerfile"
  "requirements.txt"
  "deploy.yaml"
)

# Où déposer l'archive
OUT_DIR="${OUT_DIR:-./_bundle_out}"
BUNDLE_BASENAME="${BUNDLE_BASENAME:-playwright-wrapper-srcbundle}"
TS="${TS:-$(date +%Y%m%d-%H%M%S)}"

# Optionnel: masquer la valeur de token si elle apparaît en clair (ne touche pas au code, seulement au bundle)
REDACT_SECRETS_IN_BUNDLE="${REDACT_SECRETS_IN_BUNDLE:-true}"

### =========================
### Pré-checks
### =========================
cd "$REPO_DIR"

command -v tar >/dev/null
command -v sha256sum >/dev/null
command -v python3 >/dev/null || true

mkdir -p "$OUT_DIR"

### =========================
### Sauvegardes
### =========================
BACKUP_DIR="${OUT_DIR}/_backup_files_${TS}"
mkdir -p "$BACKUP_DIR"

echo "[+] Backup des fichiers sources vers: $BACKUP_DIR"
for f in "${FILES[@]}"; do
  if [ ! -f "$f" ]; then
    echo "[!] Fichier manquant: $f"
    exit 1
  fi
  mkdir -p "$BACKUP_DIR/$(dirname "$f")"
  cp -a "$f" "$BACKUP_DIR/$f"
done

### =========================
### Préparer un répertoire de bundle (copie de travail)
### =========================
BUNDLE_DIR="${OUT_DIR}/_bundle_${TS}"
mkdir -p "$BUNDLE_DIR"

echo "[+] Copie de travail pour le bundle: $BUNDLE_DIR"
for f in "${FILES[@]}"; do
  mkdir -p "$BUNDLE_DIR/$(dirname "$f")"
  cp -a "$f" "$BUNDLE_DIR/$f"
done

### =========================
### Redaction (optionnel) dans le bundle uniquement
### =========================
if [ "$REDACT_SECRETS_IN_BUNDLE" = "true" ]; then
  echo "[+] Redaction minimale dans le bundle (sans modifier le repo)"
  # Masque des patterns évidents si jamais une valeur de token est en clair (best-effort)
  # - Ne touche PAS aux secrets K8s (non présents ici), seulement aux fichiers listés.
  python3 - <<'PY' || true
import re, pathlib

root = pathlib.Path("./_bundle_out")
# on retrouve le dernier _bundle_*
bundles = sorted([p for p in root.glob("_bundle_*") if p.is_dir()])
if not bundles:
    raise SystemExit(0)
bdir = bundles[-1]

paths = [
    bdir/"app/main.py",
    bdir/"app/settings.py",
    bdir/"deploy.yaml",
    bdir/"Dockerfile",
    bdir/"requirements.txt",
]
for p in paths:
    if not p.exists():
        continue
    txt = p.read_text(encoding="utf-8", errors="replace")
    # Remplace des valeurs explicites après api_token: ou API_TOKEN: ou "X-API-Token:"
    txt2 = re.sub(r'(\bapi_token\s*:\s*str\s*=\s*")[^"]+(")', r'\1REDACTED\2', txt)
    txt2 = re.sub(r'(\bAPI_TOKEN\b[^A-Za-z0-9]*)([A-Za-z0-9_\-]{8,})', r'\1REDACTED', txt2)
    txt2 = re.sub(r'(\bX-API-Token:\s*)(\S+)', r'\1REDACTED', txt2)
    if txt2 != txt:
        p.write_text(txt2, encoding="utf-8")
PY
fi

### =========================
### Créer l’archive + manifest
### =========================
ARCHIVE_PATH="${OUT_DIR}/${BUNDLE_BASENAME}_${TS}.tar.gz"
MANIFEST_PATH="${OUT_DIR}/${BUNDLE_BASENAME}_${TS}.manifest.txt"
SHA_PATH="${OUT_DIR}/${BUNDLE_BASENAME}_${TS}.sha256"

echo "[+] Création de l'archive: $ARCHIVE_PATH"
tar -C "$BUNDLE_DIR" -czf "$ARCHIVE_PATH" .

echo "[+] Création manifest: $MANIFEST_PATH"
{
  echo "bundle_created_at=${TS}"
  echo "repo_dir=$(pwd)"
  echo "files_included:"
  for f in "${FILES[@]}"; do
    echo "  - $f"
  done
  echo
  echo "checksums (sha256) des fichiers dans le bundle (avant tar):"
  (cd "$BUNDLE_DIR" && sha256sum "${FILES[@]}" 2>/dev/null || true)
} > "$MANIFEST_PATH"

echo "[+] SHA256 de l'archive: $SHA_PATH"
sha256sum "$ARCHIVE_PATH" | tee "$SHA_PATH" >/dev/null

### =========================
### Vérifications
### =========================
echo "[+] Vérification: l’archive est lisible et contient les fichiers attendus"
tar -tzf "$ARCHIVE_PATH" >/dev/null

missing=0
for f in "${FILES[@]}"; do
  if ! tar -tzf "$ARCHIVE_PATH" | grep -qx "$f"; then
    echo "[!] Manquant dans l'archive: $f"
    missing=1
  fi
done
if [ "$missing" -ne 0 ]; then
  echo "[!] Bundle incomplet."
  exit 1
fi

echo
echo "[OK] Bundle prêt."
echo "     Archive : $ARCHIVE_PATH"
echo "     Manifest: $MANIFEST_PATH"
echo "     SHA256   : $SHA_PATH"
echo
echo "➡️ Envoie-moi le contenu de l’archive (ou colle app/main.py + app/settings.py + deploy.yaml) et je te renverrai les fichiers modifiés pour supprimer toute auth, puis on rebuild/redeploy."
