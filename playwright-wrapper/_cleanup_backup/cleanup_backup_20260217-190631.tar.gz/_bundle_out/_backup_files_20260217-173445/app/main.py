import asyncio
import logging
import os
import secrets
import time
import shlex
from dataclasses import dataclass, field
from typing import Dict, Optional, List, Any

import httpx
from fastapi import FastAPI, Header, HTTPException, Request, Response
from fastapi.responses import StreamingResponse
from kubernetes import client, config
from kubernetes.client.rest import ApiException

from app.settings import settings

log = logging.getLogger(__name__)

logger = log  # alias for debug patches

app = FastAPI(title="Playwright Wrapper (Transparent Proxy)", version="1.0.0")


def _env_bool(name: str, default: bool) -> bool:
    v = os.getenv(name)
    if v is None:
        return default
    return v.strip().lower() in ("1", "true", "yes", "y", "on")


def _split_args(s: Optional[str]) -> Optional[List[str]]:
    if s is None:
        return None
    s = s.strip()
    if not s:
        return None
    return shlex.split(s)


def _load_kube() -> bool:
    if os.getenv("KUBE_ENABLED", "true").strip().lower() in ("0", "false", "no"):
        log.info("Kubernetes disabled via KUBE_ENABLED=false")
        return False

    in_cluster = bool(os.getenv("KUBERNETES_SERVICE_HOST")) and bool(os.getenv("KUBERNETES_SERVICE_PORT"))

    try:
        if in_cluster:
            config.load_incluster_config()
            log.info("Loaded in-cluster Kubernetes config")
            return True

        config.load_kube_config()
        log.info("Loaded kubeconfig (out-of-cluster)")
        return True

    except Exception as e:
        if os.getenv("KUBE_REQUIRED", "false").strip().lower() in ("1", "true", "yes", "y", "on"):
            raise
        log.warning("Kubernetes config not available; continuing without kube. Error=%r", e)
        return False


def _require_kube():
    if not getattr(app.state, "kube_enabled", False):
        raise HTTPException(
            status_code=503,
            detail="Kubernetes is disabled/unavailable (KUBE_ENABLED=false or no K8s config).",
        )


def _ns() -> str:
    if settings.target_namespace:
        return settings.target_namespace
    try:
        with open("/var/run/secrets/kubernetes.io/serviceaccount/namespace", "r", encoding="utf-8") as f:
            return f.read().strip()
    except FileNotFoundError:
        raise HTTPException(
            status_code=500,
            detail="target_namespace is not set and serviceaccount namespace file is missing. "
                   "Set TARGET_NAMESPACE for out-of-cluster use.",
        )


def _auth(x_api_token: Optional[str]):
    if not x_api_token or x_api_token != settings.api_token:
        raise HTTPException(status_code=401, detail="Unauthorized")


def _fail_fast_token():
    env = (settings.environment or "dev").strip().lower()
    if env == "prod" and settings.fail_if_default_token and settings.api_token == "CHANGE_ME":
        raise RuntimeError("API_TOKEN is still default (CHANGE_ME) in prod. Refusing to start.")


@dataclass
class Session:
    session_id: str
    namespace: str
    pod_name: str
    service_name: str
    target_base: str
    created_at: float = field(default_factory=lambda: time.time())
    last_activity_at: float = field(default_factory=lambda: time.time())
    active_streams: int = 0


SESSIONS: Dict[str, Session] = {}
SESSIONS_LOCK = asyncio.Lock()


@app.on_event("startup")
async def startup():
    logging.basicConfig(level=(settings.log_level or "INFO").upper())
    _fail_fast_token()

    app.state.kube_enabled = _load_kube()

    app.state.http = httpx.AsyncClient(
        follow_redirects=False,
        timeout=httpx.Timeout(
            settings.http_default_read_timeout_seconds,
            connect=settings.http_connect_timeout_seconds,
        ),
    )

    sse_read = settings.sse_read_timeout_seconds
    if sse_read and sse_read > 0:
        sse_timeout = httpx.Timeout(
            sse_read,
            connect=settings.http_connect_timeout_seconds,
            write=settings.sse_write_timeout_seconds,
        )
    else:
        sse_timeout = httpx.Timeout(
            None,
            connect=settings.http_connect_timeout_seconds,
            write=settings.sse_write_timeout_seconds,
        )

    app.state.http_sse = httpx.AsyncClient(
        follow_redirects=False,
        timeout=sse_timeout,
    )

    app.state.gc_task = asyncio.create_task(_gc_loop())


@app.on_event("shutdown")
async def shutdown():
    for c in ("http", "http_sse"):
        try:
            client_obj = getattr(app.state, c, None)
            if client_obj:
                await client_obj.aclose()
        except Exception:
            pass
    try:
        app.state.gc_task.cancel()
    except Exception:
        pass


@app.get("/health")
def health():
    return {
        "ok": True,
        "kubeEnabled": bool(getattr(app.state, "kube_enabled", False)),
        "environment": settings.environment,
        "runAsNonRoot": _env_bool("RUN_AS_NON_ROOT", settings.run_as_non_root),
        "runAsUser": int(os.getenv("RUN_AS_USER", str(settings.run_as_user))),
        "runAsGroup": int(os.getenv("RUN_AS_GROUP", str(settings.run_as_group))),
        "image": settings.playwright_image,
        "port": settings.playwright_port,
        "serviceType": settings.service_type,
        "nodeAddress": settings.node_address,
        "pvcEnabled": bool(settings.enable_pvc_mount),
        "playwrightCommand": settings.playwright_command,
        "playwrightArgs": settings.playwright_args,
    }


def _hop_by_hop_header(name: str) -> bool:
    h = name.lower()
    return h in {
        "connection",
        "keep-alive",
        "proxy-authenticate",
        "proxy-authorization",
        "te",
        "trailers",
        "transfer-encoding",
        "upgrade",
    }


async def _touch(session_id: str):
    async with SESSIONS_LOCK:
        s = SESSIONS.get(session_id)
        if s:
            s.last_activity_at = time.time()


def _k8s_delete_session(namespace: str, session_id: str) -> None:
    _require_kube()
    core = client.CoreV1Api()

    pod_name = f"pw-{session_id}"
    svc_name = f"pw-svc-{session_id}"

    try:
        core.delete_namespaced_service(name=svc_name, namespace=namespace)
    except ApiException as e:
        print('K8S_APIEXC_DEBUG:', getattr(e, 'status', None), getattr(e, 'reason', None), getattr(e, 'body', None))
        try:
            logger.exception('K8S_APIEXC_DEBUG logger: status=%s reason=%s body=%s', getattr(e, 'status', None), getattr(e, 'reason', None), getattr(e, 'body', None))
        except Exception:
            pass
        if e.status != 404:
            raise

    try:
        core.delete_namespaced_pod(name=pod_name, namespace=namespace, grace_period_seconds=0)
    except ApiException as e:
        print('K8S_APIEXC_DEBUG:', getattr(e, 'status', None), getattr(e, 'reason', None), getattr(e, 'body', None))
        try:
            logger.exception('K8S_APIEXC_DEBUG logger: status=%s reason=%s body=%s', getattr(e, 'status', None), getattr(e, 'reason', None), getattr(e, 'body', None))
        except Exception:
            pass
        if e.status != 404:
            raise


def _build_security_contexts():
    run_as_non_root = _env_bool("RUN_AS_NON_ROOT", settings.run_as_non_root)
    run_as_user = int(os.getenv("RUN_AS_USER", str(settings.run_as_user)))
    run_as_group = int(os.getenv("RUN_AS_GROUP", str(settings.run_as_group)))

    container_security_ctx = None
    pod_security_ctx = None

    if run_as_non_root:
        caps = None
        if settings.drop_all_caps:
            caps = client.V1Capabilities(drop=["ALL"])

        seccomp = None
        if settings.seccomp_runtime_default:
            seccomp = client.V1SeccompProfile(type="RuntimeDefault")

        container_security_ctx = client.V1SecurityContext(
            run_as_non_root=True,
            run_as_user=run_as_user,
            run_as_group=run_as_group,
            allow_privilege_escalation=settings.allow_privilege_escalation,
            read_only_root_filesystem=settings.read_only_root_filesystem,
            capabilities=caps,
            seccomp_profile=seccomp,
        )

        fs_group = settings.fs_group if settings.enable_pvc_mount else None

        pod_security_ctx = client.V1PodSecurityContext(
            run_as_non_root=True,
            run_as_user=run_as_user,
            run_as_group=run_as_group,
            fs_group=fs_group,
            seccomp_profile=seccomp,
        )

    return container_security_ctx, pod_security_ctx


async def _k8s_create_pod_and_service(namespace: str, session_id: str) -> tuple[str, str]:
    _require_kube()
    core = client.CoreV1Api()

    pod_name = f"pw-{session_id}"
    svc_name = f"pw-svc-{session_id}"
    labels = {"app": "playwright-ephemeral", "sessionId": session_id}

    volume_mounts = []
    volumes = []

    if settings.enable_pvc_mount:
        volumes.append(
            client.V1Volume(
                name="artifacts",
                persistent_volume_claim=client.V1PersistentVolumeClaimVolumeSource(
                    claim_name=settings.pvc_name
                ),
            )
        )
        volume_mounts.append(client.V1VolumeMount(name="artifacts", mount_path=settings.pvc_mount_path))

    command_list = _split_args(settings.playwright_command) or ["node"]
    args_list = _split_args(settings.playwright_args)

    # If args are not provided, use a safe default that binds on all interfaces.
    # Some MCP builds bind on localhost only ("Listening on http://localhost:8933"),
    # which makes podIP:port unreachable => readiness probe fails => /sessions 504.
    if not args_list:
        args_list = [
            "cli.js",
            "--headless",
            "--browser",
            "chromium",
            "--no-sandbox",
            "--host",
            "0.0.0.0",
            "--port",
            str(settings.playwright_port),
            "--shared-browser-context",
        ]
    else:
        # Ensure host binding is not localhost-only
        if "--host" not in args_list and "--bind" not in args_list:
            args_list = list(args_list)
            # Insert right after cli.js if present, otherwise prepend
            insert_at = 1 if len(args_list) >= 1 else 0
            args_list[insert_at:insert_at] = ["--host", "0.0.0.0"]

        # Ensure port is present and matches settings.playwright_port
        if "--port" not in args_list:
            args_list = list(args_list) + ["--port", str(settings.playwright_port)]

    container_security_ctx, pod_security_ctx = _build_security_contexts()

    container = client.V1Container(
        name="playwright",
        image=settings.playwright_image,
        image_pull_policy="IfNotPresent",
        command=command_list,
        args=args_list,
        ports=[client.V1ContainerPort(container_port=settings.playwright_port, name="mcp")],
        volume_mounts=volume_mounts or None,
        security_context=container_security_ctx,
        readiness_probe=client.V1Probe(
            tcp_socket=client.V1TCPSocketAction(port=settings.playwright_port),
            initial_delay_seconds=2,
            period_seconds=2,
            timeout_seconds=1,
            failure_threshold=30,
        ),
    )

    pod_spec = client.V1PodSpec(
        containers=[container],
        restart_policy="Never",
        volumes=volumes or None,
        security_context=pod_security_ctx,
    )

    pod = client.V1Pod(
        api_version="v1",
        kind="Pod",
        metadata=client.V1ObjectMeta(name=pod_name, labels=labels),
        spec=pod_spec,
    )

    svc_type = (settings.service_type or "ClusterIP").strip()
    if svc_type not in ("ClusterIP", "NodePort"):
        raise HTTPException(status_code=500, detail=f"Unsupported SERVICE_TYPE: {svc_type}")

    svc_port = client.V1ServicePort(
        name="mcp",
        port=settings.playwright_port,
        target_port=settings.playwright_port,
    )

    svc = client.V1Service(
        api_version="v1",
        kind="Service",
        metadata=client.V1ObjectMeta(name=svc_name, labels=labels),
        spec=client.V1ServiceSpec(
            selector=labels,
            ports=[svc_port],
            type=svc_type,
        ),
    )

    core.create_namespaced_pod(namespace=namespace, body=pod)
    core.create_namespaced_service(namespace=namespace, body=svc)

    return pod_name, svc_name


def _pod_debug_state(pod: Any) -> str:
    try:
        cs = (pod.status.container_statuses or [])
        if cs:
            st = cs[0].state
            if st and st.waiting:
                return f"waiting(reason={st.waiting.reason}, message={st.waiting.message})"
            if st and st.terminated:
                return f"terminated(exitCode={st.terminated.exit_code}, reason={st.terminated.reason}, message={st.terminated.message})"
            if st and st.running:
                return "running"
        return "unknown"
    except Exception:
        return "unknown"


async def _k8s_wait_pod_ready(namespace: str, session_id: str, timeout_s: int) -> None:
    _require_kube()
    core = client.CoreV1Api()
    pod_name = f"pw-{session_id}"

    deadline = time.time() + timeout_s
    last_phase = None
    last_reason = None
    last_dbg = None

    while time.time() < deadline:
        pod = core.read_namespaced_pod(name=pod_name, namespace=namespace)
        last_phase = pod.status.phase
        last_dbg = _pod_debug_state(pod)

        cs = (pod.status.container_statuses or [])
        if cs and cs[0].state and cs[0].state.waiting:
            last_reason = cs[0].state.waiting.reason
        if cs and cs[0].state and cs[0].state.terminated:
            term = cs[0].state.terminated
            raise HTTPException(
                status_code=500,
                detail=f"Pod terminated early (phase={last_phase}, exitCode={term.exit_code}, reason={term.reason})",
            )

        conds = pod.status.conditions or []
        if any(c.type == "Ready" and c.status == "True" for c in conds):
            return

        await asyncio.sleep(1)

    detail = "Pod not ready in time"
    if last_phase or last_reason or last_dbg:
        detail += f" (lastPhase={last_phase}, lastReason={last_reason}, state={last_dbg})"
    raise HTTPException(status_code=504, detail=detail)


def _k8s_get_nodeport(namespace: str, svc_name: str) -> int:
    _require_kube()
    core = client.CoreV1Api()
    svc = core.read_namespaced_service(name=svc_name, namespace=namespace)
    ports = (svc.spec.ports or [])
    if not ports:
        raise HTTPException(status_code=502, detail="Service has no ports")
    np = ports[0].node_port
    if not np:
        raise HTTPException(status_code=502, detail="Service NodePort not allocated yet")
    return int(np)

# ---------------------------------------------------------------------------
# n8n-friendly stable MCP endpoint (no sessionId in client)
# - /mcp and /mcp/{path} create/reuse a sticky session then reuse proxy_any()
# ---------------------------------------------------------------------------
_MCP_STICKY_LOCK = asyncio.Lock()
_MCP_STICKY_SESSION_ID: Optional[str] = None


async def _get_or_create_sticky_session_id(x_api_token: Optional[str]) -> str:
    # ensure token is valid
    _auth(x_api_token)

    global _MCP_STICKY_SESSION_ID
    async with _MCP_STICKY_LOCK:
        # reuse if session still exists
        if _MCP_STICKY_SESSION_ID:
            async with SESSIONS_LOCK:
                if _MCP_STICKY_SESSION_ID in SESSIONS:
                    return _MCP_STICKY_SESSION_ID

        # create a new session using existing endpoint logic
        data = await create_session(x_api_token=x_api_token)
        sid = data.get("sessionId")
        if not sid:
            raise HTTPException(status_code=500, detail="Sticky session creation failed: missing sessionId")
        _MCP_STICKY_SESSION_ID = sid
        return sid


@app.api_route("/mcp", methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS", "HEAD"])
async def mcp_root(request: Request, x_api_token: Optional[str] = Header(default=None)):
    sid = await _get_or_create_sticky_session_id(x_api_token)
    # Playwright MCP endpoint behind the session is /mcp (or /sse depending on client)
    return await proxy_any(session_id=sid, path="mcp", request=request, x_api_token=x_api_token)


@app.api_route("/mcp/{path:path}", methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS", "HEAD"])
async def mcp_subpath(path: str, request: Request, x_api_token: Optional[str] = Header(default=None)):
    sid = await _get_or_create_sticky_session_id(x_api_token)
    # forward to /mcp/<path> behind the session
    return await proxy_any(session_id=sid, path=f"mcp/{path}", request=request, x_api_token=x_api_token)



@app.post("/sessions")
async def create_session(x_api_token: Optional[str] = Header(default=None)):
    _auth(x_api_token)
    _require_kube()

    namespace = _ns()
    session_id = secrets.token_hex(8)

    keep_failed = _env_bool("KEEP_FAILED_RESOURCES", False)
    timeout_s = int(os.getenv("POD_READY_TIMEOUT_SECONDS", str(settings.pod_ready_timeout_seconds)))

    try:
        pod_name, svc_name = await _k8s_create_pod_and_service(namespace, session_id)
        await _k8s_wait_pod_ready(namespace, session_id, timeout_s)

        svc_type = (settings.service_type or "ClusterIP").strip()
        if svc_type == "NodePort":
            node_port = _k8s_get_nodeport(namespace, svc_name)
            target_base = f"http://{settings.node_address}:{node_port}"
        else:
            target_base = f"http://{svc_name}.{namespace}.svc.cluster.local:{settings.playwright_port}"

    except HTTPException:
        if not keep_failed:
            try:
                _k8s_delete_session(namespace, session_id)
            except Exception:
                pass
        raise
    except ApiException as e:
        print('K8S_APIEXC_DEBUG:', getattr(e, 'status', None), getattr(e, 'reason', None), getattr(e, 'body', None))
        try:
            logger.exception('K8S_APIEXC_DEBUG logger: status=%s reason=%s body=%s', getattr(e, 'status', None), getattr(e, 'reason', None), getattr(e, 'body', None))
        except Exception:
            pass
        if not keep_failed:
            try:
                _k8s_delete_session(namespace, session_id)
            except Exception:
                pass
        # --- added debug: log Kubernetes ApiException details when returning Forbidden ---
        try:
            logger.exception(
                "K8s ApiException captured: status=%s reason=%s body=%s headers=%s",
                getattr(e, 'status', None),
                getattr(e, 'reason', None),
                getattr(e, 'body', None),
                getattr(e, 'headers', None),
            )
        except NameError:
            logger.exception("K8s error returned but variable 'e' not found in scope")
        # --- added debug: universal exception dump right before returning 'K8s error:' ---
        try:
            _ex = e
        except NameError:
            _ex = None
        if _ex is None:
            try:
                _ex = exc
            except NameError:
                _ex = None
        if _ex is None:
            try:
                _ex = err
            except NameError:
                _ex = None
        print('K8S_ANYEXC_DEBUG:', type(_ex).__name__ if _ex else None, repr(_ex) if _ex else None, 'status=' + str(getattr(_ex, 'status', None)) if _ex else None, 'reason=' + str(getattr(_ex, 'reason', None)) if _ex else None, 'body=' + str(getattr(_ex, 'body', None)) if _ex else None, flush=True)
        raise HTTPException(status_code=500, detail=f"K8s error: {e.reason}")

    async with SESSIONS_LOCK:
        SESSIONS[session_id] = Session(
            session_id=session_id,
            namespace=namespace,
            pod_name=pod_name,
            service_name=svc_name,
            target_base=target_base,
        )

    log.info("Session created sessionId=%s ns=%s pod=%s svc=%s targetBase=%s",
             session_id, namespace, pod_name, svc_name, target_base)

    return {
        "sessionId": session_id,
        "namespace": namespace,
        "podName": pod_name,
        "serviceName": svc_name,
        "targetBase": target_base,
        "baseUrl": f"/sessions/{session_id}",
    }


@app.delete("/sessions/{session_id}")
async def delete_session(session_id: str, x_api_token: Optional[str] = Header(default=None)):
    _auth(x_api_token)
    _require_kube()

    async with SESSIONS_LOCK:
        s = SESSIONS.pop(session_id, None)

    if not s:
        return {"ok": True, "sessionId": session_id, "deleted": False}

    try:
        _k8s_delete_session(s.namespace, session_id)
    except ApiException as e:
        print('K8S_APIEXC_DEBUG:', getattr(e, 'status', None), getattr(e, 'reason', None), getattr(e, 'body', None))
        try:
            logger.exception('K8S_APIEXC_DEBUG logger: status=%s reason=%s body=%s', getattr(e, 'status', None), getattr(e, 'reason', None), getattr(e, 'body', None))
        except Exception:
            pass
        raise HTTPException(status_code=500, detail=f"K8s delete error: {e.reason}")

    log.info("Session deleted sessionId=%s ns=%s", session_id, s.namespace)
    return {"ok": True, "sessionId": session_id, "deleted": True}


def _is_sse_request(request: Request, path: str) -> bool:
    accept = (request.headers.get("accept", "") or "").lower()
    if "text/event-stream" in accept:
        return True
    if path.strip("/").lower().startswith("sse"):
        return True
    return False


@app.api_route("/sessions/{session_id}/{path:path}", methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS", "HEAD"])
async def proxy_any(session_id: str, path: str, request: Request, x_api_token: Optional[str] = Header(default=None)):
    _auth(x_api_token)

    async with SESSIONS_LOCK:
        s = SESSIONS.get(session_id)
    if not s:
        raise HTTPException(status_code=404, detail="Unknown session")

    await _touch(session_id)

    upstream_url = f"{s.target_base}/{path}"
    if request.url.query:
        upstream_url = f"{upstream_url}?{request.url.query}"

    headers = {}
    for k, v in request.headers.items():
        if _hop_by_hop_header(k):
            continue
        if k.lower() == "host":
            continue
        headers[k] = v

    # ✅ IMPORTANT: Playwright MCP restreint l'accès au Host "localhost:<port>"
    # On force donc le Host pour l'upstream.
    headers["host"] = f"localhost:{settings.playwright_port}"
    headers.setdefault("origin", f"http://localhost:{settings.playwright_port}")
    headers.setdefault("referer", f"http://localhost:{settings.playwright_port}/")

    body = await request.body()
    method = request.method.upper()
    is_sse = _is_sse_request(request, path)

    try:
        if is_sse:
            async with SESSIONS_LOCK:
                ss = SESSIONS.get(session_id)
                if ss:
                    ss.active_streams += 1

            async with app.state.http_sse.stream(method, upstream_url, headers=headers, content=body) as r:
                resp_headers = {
                    k: v for k, v in r.headers.items()
                    if (not _hop_by_hop_header(k)) and (k.lower() != "content-length")
                }
                resp_headers["content-type"] = "text/event-stream"
                resp_headers.setdefault("cache-control", "no-cache")

                log.info("SSE proxy start sessionId=%s method=%s url=%s status=%s",
                         session_id, method, upstream_url, r.status_code)

                async def _stream_sse_text():
                    try:
                        async for chunk in r.aiter_text():
                            await _touch(session_id)
                            yield chunk
                    except (httpx.StreamClosed, asyncio.CancelledError):
                        return
                    except Exception as e:
                        log.info("SSE stream ended with error: %r", e)
                        return
                    finally:
                        async with SESSIONS_LOCK:
                            ss2 = SESSIONS.get(session_id)
                            if ss2 and ss2.active_streams > 0:
                                ss2.active_streams -= 1
                            if ss2:
                                ss2.last_activity_at = time.time()
                        log.info("SSE proxy end sessionId=%s url=%s", session_id, upstream_url)

                return StreamingResponse(
                    _stream_sse_text(),
                    status_code=r.status_code,
                    headers=resp_headers,
                )

        r = await app.state.http.request(method, upstream_url, headers=headers, content=body)
        resp_headers = {k: v for k, v in r.headers.items() if not _hop_by_hop_header(k)}
        log.info("Proxy sessionId=%s method=%s url=%s status=%s", session_id, method, upstream_url, r.status_code)

        return Response(
            content=r.content,
            status_code=r.status_code,
            headers=resp_headers,
            media_type=r.headers.get("content-type"),
        )

    except httpx.ConnectTimeout:
        raise HTTPException(status_code=504, detail="Upstream connect timeout")
    except httpx.ReadTimeout:
        raise HTTPException(status_code=504, detail="Upstream read timeout")
    except httpx.ConnectError as e:
        raise HTTPException(status_code=502, detail=f"Upstream connect error: {e!s}")
    except httpx.HTTPError as e:
        raise HTTPException(status_code=502, detail=f"Upstream HTTP error: {e!s}")


async def _gc_loop():
    while True:
        try:
            await asyncio.sleep(settings.gc_interval_seconds)
            now = time.time()
            ttl_s = settings.session_ttl_minutes * 60

            to_delete = []
            async with SESSIONS_LOCK:
                for sid, s in list(SESSIONS.items()):
                    if s.active_streams > 0:
                        continue
                    if now - s.last_activity_at > ttl_s:
                        to_delete.append(sid)

            for sid in to_delete:
                async with SESSIONS_LOCK:
                    s = SESSIONS.pop(sid, None)
                if not s:
                    continue
                try:
                    _k8s_delete_session(s.namespace, sid)
                    log.info("GC deleted sessionId=%s ns=%s", sid, s.namespace)
                except Exception as e:
                    log.warning("GC failed to delete sessionId=%s err=%r", sid, e)

        except asyncio.CancelledError:
            return
        except Exception:
            continue
