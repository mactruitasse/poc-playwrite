#!/usr/bin/env bash
set -euo pipefail

### =========================
### Config
### =========================
REPO_DIR="${REPO_DIR:-.}"

KIND_CLUSTER_NAME="${KIND_CLUSTER_NAME:-pw}"
BASE_REPO="${BASE_REPO:-playwright-wrapper}"
NEW_TAG="${NEW_TAG:-local-sse-proxyfix-$(date +%Y%m%d-%H%M%S)}"
NEW_IMAGE="${NEW_IMAGE:-${BASE_REPO}:${NEW_TAG}}"

NS="${NS:-n8n-prod}"
DEPLOY="${DEPLOY:-playwright-wrapper}"
CONTAINER="${CONTAINER:-wrapper}"
ROLLOUT_TIMEOUT="${ROLLOUT_TIMEOUT:-240s}"

MAIN_PY="${MAIN_PY:-app/main.py}"

SERVICE_HOST="${SERVICE_HOST:-playwright-wrapper.${NS}.svc}"
SERVICE_PORT="${SERVICE_PORT:-8080}"

CURL_IMAGE="${CURL_IMAGE:-curlimages/curl:8.6.0}"

### =========================
### Pre-checks
### =========================
cd "$REPO_DIR"
command -v python3 >/dev/null || { echo "[!] python3 manquant"; exit 1; }
command -v docker >/dev/null || { echo "[!] docker manquant"; exit 1; }
command -v kind >/dev/null || { echo "[!] kind manquant"; exit 1; }
command -v kubectl >/dev/null || { echo "[!] kubectl manquant"; exit 1; }

[ -f "$MAIN_PY" ] || { echo "[!] Fichier manquant: $MAIN_PY"; exit 1; }

TS="$(date +%Y%m%d-%H%M%S)"
BACKUP_DIR="./_backup_sse_proxyfix_${TS}"
mkdir -p "$BACKUP_DIR/app"
cp -a "$MAIN_PY" "$BACKUP_DIR/app/main.py.bak"
echo "[+] Backup -> $BACKUP_DIR"

### =========================
### Patch: remove x_api_token kwarg in proxy_any calls inside sse_root/sse_subpath
### =========================
echo "[+] Patch $MAIN_PY : remove x_api_token=... from proxy_any() in sse_*"

python3 - <<'PY'
from pathlib import Path
import re

p = Path("app/main.py")
s = p.read_text(encoding="utf-8")

def patch_func(src: str, func_name: str) -> tuple[str, int]:
    pattern = re.compile(
        rf'(?ms)^(async\s+def\s+{re.escape(func_name)}\s*\(.*?\)\s*:\s*\n)(.*?)(?=^@app\.|^async\s+def\s+|^def\s+|\Z)'
    )
    m = pattern.search(src)
    if not m:
        return src, 0

    header, body = m.group(1), m.group(2)
    orig = body

    # Remove ", x_api_token=..." argument in proxy_any(...) calls (handle optional whitespace)
    body = re.sub(r'(proxy_any\s*\([^)]*?),\s*x_api_token\s*=\s*[^),]+(\s*[),])', r'\1\2', body)

    # Also handle case where x_api_token is last arg before ')'
    body = re.sub(r'(proxy_any\s*\([^)]*?),\s*x_api_token\s*=\s*[^)]+\)', r'\1)', body)

    if body == orig:
        return src, 0

    new_block = header + body
    src2 = src[:m.start()] + new_block + src[m.start()+len(m.group(0)):]
    return src2, 1

s2, n1 = patch_func(s, "sse_root")
s2, n2 = patch_func(s2, "sse_subpath")

total = n1 + n2
if total == 0:
    raise SystemExit("ERROR: aucun changement appliqué (sse_root/sse_subpath introuvables ou pas d'appel proxy_any(..., x_api_token=...)).")

p.write_text(s2, encoding="utf-8")
print(f"patched_funcs={total}")
PY

echo "[+] Vérification compile Python"
python3 -m compileall -q app

### =========================
### Build + kind load
### =========================
echo "[+] Build image: $NEW_IMAGE"
docker build -t "$NEW_IMAGE" .

echo "[+] kind load docker-image \"$NEW_IMAGE\" --name \"$KIND_CLUSTER_NAME\""
kind load docker-image "$NEW_IMAGE" --name "$KIND_CLUSTER_NAME"

### =========================
### Deploy + rollout
### =========================
echo "[+] kubectl set image deploy/$DEPLOY $CONTAINER=$NEW_IMAGE -n $NS"
kubectl -n "$NS" set image "deploy/$DEPLOY" "$CONTAINER=$NEW_IMAGE"

echo "[+] rollout restart deploy/$DEPLOY -n $NS"
kubectl -n "$NS" rollout restart "deploy/$DEPLOY"

echo "[+] rollout status (timeout=$ROLLOUT_TIMEOUT)"
kubectl -n "$NS" rollout status "deploy/$DEPLOY" --timeout="$ROLLOUT_TIMEOUT"

### =========================
### Tests
### =========================
echo "[+] Test /health (max-time 5)"
kubectl -n "$NS" run curltest-health5 --rm -i --restart=Never --image="$CURL_IMAGE" -- \
  sh -lc "curl -sS -i --max-time 5 http://${SERVICE_HOST}:${SERVICE_PORT}/health | sed -n '1,40p'"

echo
echo "[+] Test /sse (max-time 2) - on attend un 200 + Content-Type: text/event-stream + event endpoint"
kubectl -n "$NS" run curltest-sse5 --rm -i --restart=Never --image="$CURL_IMAGE" -- \
  sh -lc "curl -sS -i --max-time 2 -H 'Accept: text/event-stream' http://${SERVICE_HOST}:${SERVICE_PORT}/sse | sed -n '1,120p' || true"

echo
echo "[+] Wrapper logs (tail 120) après test /sse"
POD="$(kubectl -n "$NS" get pods -l app.kubernetes.io/instance=n8n-prod,app.kubernetes.io/name=playwright-wrapper \
  --sort-by=.metadata.creationTimestamp -o jsonpath='{range .items[*]}{.metadata.name}{"\n"}{end}' | tail -n 1)"
echo "[+] Pod: $POD"
kubectl -n "$NS" logs "$POD" --tail=120 || true

echo "[OK] Déployé: $NEW_IMAGE"
echo "     Backups: $BACKUP_DIR"
