#!/usr/bin/env bash
set -euo pipefail

############################################
# Config
############################################
ROOT_DIR="${ROOT_DIR:-.}"                       # répertoire du projet
BACKUP_DIR="${BACKUP_DIR:-./_cleanup_backup}"   # où stocker la sauvegarde
BACKUP_TS="$(date +%Y%m%d-%H%M%S)"
KEEP_SH_ANYWHERE="${KEEP_SH_ANYWHERE:-1}"       # 1 = garder tous les *.sh partout ; 0 = garder seulement ./ *.sh
DRY_RUN="${DRY_RUN:-0}"                         # 1 = ne supprime rien, affiche seulement

############################################
# Safety checks
############################################
cd "$ROOT_DIR"

if [[ ! -d "app" ]]; then
  echo "ERREUR: ./app/ introuvable dans $(pwd). Abandon."
  exit 1
fi

if [[ ! -f "Dockerfile" ]]; then
  echo "ERREUR: ./Dockerfile introuvable dans $(pwd). Abandon."
  exit 1
fi

if [[ ! -f "requirements.txt" ]]; then
  echo "ERREUR: ./requirements.txt introuvable dans $(pwd). Abandon."
  exit 1
fi

############################################
# Backup (tar.gz)
############################################
mkdir -p "$BACKUP_DIR"
BACKUP_ARCHIVE="$BACKUP_DIR/cleanup_backup_${BACKUP_TS}.tar.gz"

echo "==> Sauvegarde complète du répertoire $(pwd) vers: $BACKUP_ARCHIVE"
tar -czf "$BACKUP_ARCHIVE" .

############################################
# Build keep list (find paths to keep)
############################################
declare -a KEEP_PATHS
KEEP_PATHS+=("./app")
KEEP_PATHS+=("./Dockerfile")
KEEP_PATHS+=("./requirements.txt")

if [[ "$KEEP_SH_ANYWHERE" == "1" ]]; then
  # Tous les *.sh partout
  while IFS= read -r -d '' f; do
    KEEP_PATHS+=("./${f#./}")
  done < <(find . -type f -name "*.sh" -print0)
else
  # Seulement les *.sh à la racine
  while IFS= read -r -d '' f; do
    KEEP_PATHS+=("./${f#./}")
  done < <(find . -maxdepth 1 -type f -name "*.sh" -print0)
fi

# Déduplique
declare -A SEEN
declare -a KEEP_UNIQ
for p in "${KEEP_PATHS[@]}"; do
  if [[ -z "${SEEN[$p]+x}" ]]; then
    SEEN["$p"]=1
    KEEP_UNIQ+=("$p")
  fi
done

echo "==> Éléments conservés:"
for p in "${KEEP_UNIQ[@]}"; do
  echo "  - $p"
done

############################################
# Compute deletion set: everything except keep set
############################################
echo "==> Calcul des éléments à supprimer..."
declare -a TO_DELETE

# On parcourt tout au niveau racine (fichiers + dossiers), puis on exclut ce qu'on garde.
while IFS= read -r -d '' item; do
  # Normalise en ./xxx
  n="./${item#./}"

  # On ne touche jamais au backup dir (pour éviter auto-destruction)
  if [[ "$n" == "./${BACKUP_DIR#./}"* ]]; then
    continue
  fi

  # Conserver app/ et son contenu
  if [[ "$n" == "./app" || "$n" == "./app/"* ]]; then
    continue
  fi

  # Conserver Dockerfile et requirements
  if [[ "$n" == "./Dockerfile" || "$n" == "./requirements.txt" ]]; then
    continue
  fi

  # Conserver *.sh selon la règle choisie
  if [[ "$KEEP_SH_ANYWHERE" == "1" ]]; then
    if [[ -f "$n" && "$n" == *.sh ]]; then
      continue
    fi
  else
    if [[ -f "$n" && "$n" == ./*.sh && "$n" != */*/* ]]; then
      # ./*.sh à la racine (déjà sous forme ./file.sh)
      continue
    fi
  fi

  TO_DELETE+=("$n")
done < <(find . -mindepth 1 -maxdepth 1 -print0)

if [[ "${#TO_DELETE[@]}" -eq 0 ]]; then
  echo "==> Rien à supprimer (déjà propre)."
else
  echo "==> À supprimer (niveau racine):"
  for x in "${TO_DELETE[@]}"; do
    echo "  - $x"
  done
fi

############################################
# Delete
############################################
if [[ "$DRY_RUN" == "1" ]]; then
  echo "==> DRY_RUN=1 : aucune suppression effectuée."
else
  echo "==> Suppression..."
  for x in "${TO_DELETE[@]}"; do
    rm -rf -- "$x"
  done
  echo "==> Suppression terminée."
fi

############################################
# Verification
############################################
echo "==> Vérification du résultat..."
fail=0

# 1) app existe
[[ -d "./app" ]] || { echo "KO: ./app manquant"; fail=1; }

# 2) Dockerfile et requirements existent
[[ -f "./Dockerfile" ]] || { echo "KO: ./Dockerfile manquant"; fail=1; }
[[ -f "./requirements.txt" ]] || { echo "KO: ./requirements.txt manquant"; fail=1; }

# 3) pas d'autres éléments au niveau racine (sauf .sh + backup dir)
while IFS= read -r -d '' item; do
  n="./${item#./}"

  # ignore backup dir
  if [[ "$n" == "./${BACKUP_DIR#./}"* ]]; then
    continue
  fi

  # allowed
  if [[ "$n" == "./app" || "$n" == "./Dockerfile" || "$n" == "./requirements.txt" ]]; then
    continue
  fi

  # allowed sh at root
  if [[ -f "$n" && "$n" == ./*.sh ]]; then
    continue
  fi

  echo "KO: élément inattendu au niveau racine: $n"
  fail=1
done < <(find . -mindepth 1 -maxdepth 1 -print0)

if [[ "$fail" -eq 0 ]]; then
  echo "OK: nettoyage conforme."
  echo "Sauvegarde: $BACKUP_ARCHIVE"
else
  echo "ERREUR: vérification échouée. Restaure via:"
  echo "  tar -xzf '$BACKUP_ARCHIVE' -C /chemin/de/restauration"
  exit 1
fi
